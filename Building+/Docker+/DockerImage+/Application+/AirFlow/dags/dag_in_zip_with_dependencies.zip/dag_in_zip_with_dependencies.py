"""Put a DAG into a ZIP archive (with dependencies)"""
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime

from tool_package.string_utils import get_a_string

default_args = {
    'start_date': datetime.now()
}

dag = DAG(
    'dag_in_zip_with_dependencies',
    default_args=default_args)


def print_the_string():
    print("The string is:", get_a_string())


python_operator_task = PythonOperator(
    task_id='python_operator_task',
    python_callable=print_the_string,
    dag=dag)
