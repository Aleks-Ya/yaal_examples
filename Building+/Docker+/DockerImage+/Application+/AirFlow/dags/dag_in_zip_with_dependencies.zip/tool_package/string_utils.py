def get_a_string():
    return 'abc'
